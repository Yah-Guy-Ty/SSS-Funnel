"use client"

import { motion, useInView } from "framer-motion"
import { useRef } from "react"
import Image from "next/image"

export function FounderStory() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: "-80px" })

  return (
    <section id="founder" className="relative py-20 md:py-28 bg-[#264653] overflow-hidden noise-overlay">
      {/* Ambient glow */}
      <motion.div
        className="absolute top-0 right-0 w-[500px] h-[500px] rounded-full bg-[#f4a261]/5 blur-[200px]"
        animate={{ scale: [1, 1.05, 1] }}
        transition={{ duration: 10, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut" }}
      />

      <div ref={ref} className="max-w-5xl mx-auto px-6 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, ease: [0.25, 0.4, 0.25, 1] }}
          className="text-center mb-14"
        >
          <motion.span
            className="font-mono text-[#f4a261] text-xs tracking-[0.3em] uppercase inline-block"
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
          >
            OUR STORY
          </motion.span>

          <div className="overflow-hidden mt-3">
            <motion.h2
              className="text-3xl md:text-5xl font-serif text-[#F5F2ED] leading-tight text-balance"
              initial={{ y: 60 }}
              whileInView={{ y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, ease: [0.25, 0.4, 0.25, 1], delay: 0.15 }}
            >
              Started in the Family Business.{" "}
              <span className="text-[#e9c46a]">Built for Businesses Like Yours.</span>
            </motion.h2>
          </div>
        </motion.div>

        <div className="grid md:grid-cols-5 gap-10 items-center">
          {/* Founder image */}
          <motion.div
            className="md:col-span-2 flex justify-center"
            initial={{ opacity: 0, x: -40 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.7, ease: [0.25, 0.4, 0.25, 1] }}
          >
            <div className="relative">
              <motion.div
                className="absolute -inset-3 rounded-2xl bg-[#e76f51]/10 blur-xl"
                animate={{ scale: [1, 1.05, 1] }}
                transition={{ duration: 6, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut" }}
              />
              <div className="relative w-64 h-80 md:w-72 md:h-96 rounded-2xl overflow-hidden border-2 border-[#F5F2ED]/10">
                <Image
                  src="/images/founder-ty-betts.jpg"
                  alt="Ty Betts, Founder of Street Savvy Solutions"
                  fill
                  className="object-cover"
                />
              </div>
            </div>
          </motion.div>

          {/* Story text */}
          <motion.div
            className="md:col-span-3 space-y-5"
            initial={{ opacity: 0, x: 40 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.7, delay: 0.2, ease: [0.25, 0.4, 0.25, 1] }}
          >
            <p className="text-[#F5F2ED]/80 text-base md:text-lg leading-relaxed">
              I grew up inside a family HVAC business right here in Metro Atlanta. I watched my dad answer calls between jobs, spend thousands on ads that stopped working, and hire marketing companies that treated him like an afterthought.
            </p>
            <p className="text-[#F5F2ED]/80 text-base md:text-lg leading-relaxed">
              When I discovered what modern automation could do for businesses like his — respond to every call, follow up with every lead, show up on Google without spending a fortune — I knew I had to build it for other owners going through the same thing.
            </p>
            <p className="text-[#F5F2ED]/80 text-base md:text-lg leading-relaxed">
              Street Savvy Solutions exists because local business owners deserve the same marketing systems that big corporations use,{" "}
              <span className="text-[#e9c46a] font-semibold">at a price that actually makes sense.</span>
            </p>
            <motion.div
              className="pt-4 border-t border-[#F5F2ED]/10"
              initial={{ opacity: 0 }}
              animate={isInView ? { opacity: 1 } : {}}
              transition={{ delay: 0.6 }}
            >
              <p className="text-[#f4a261] font-serif text-lg">— Ty Betts</p>
              <p className="text-[#F5F2ED]/40 text-sm font-mono">Founder, Street Savvy Solutions</p>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
