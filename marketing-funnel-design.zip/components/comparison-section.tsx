"use client"

import { motion, useInView } from "framer-motion"
import { useRef } from "react"
import { X, Check } from "lucide-react"

const comparisons = [
  {
    agency: "$2,000-5,000/month retainers",
    sss: "Transparent pricing, no bloat",
  },
  {
    agency: "Pretty reports, unclear ROI",
    sss: "One dashboard showing real leads and revenue",
  },
  {
    agency: "6-month contracts",
    sss: "Month-to-month after setup",
  },
  {
    agency: "Generic strategies across industries",
    sss: "Systems built for YOUR type of business",
  },
  {
    agency: "Takes weeks to launch",
    sss: "Core systems live in under 2 weeks",
  },
  {
    agency: "You're one of 50 clients",
    sss: "You work directly with the founder",
  },
]

export function ComparisonSection() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: "-80px" })

  return (
    <section className="relative py-20 md:py-28 bg-[#F5F2ED] overflow-hidden">
      <div className="max-w-5xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, ease: [0.25, 0.4, 0.25, 1] }}
          className="text-center mb-14"
        >
          <motion.span
            className="font-mono text-[#e76f51] text-xs tracking-[0.3em] uppercase inline-block"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
          >
            WHY US
          </motion.span>

          <div className="overflow-hidden mt-3">
            <motion.h2
              className="text-3xl md:text-5xl font-serif text-[#1a323d] leading-tight text-balance"
              initial={{ y: 60 }}
              whileInView={{ y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, ease: [0.25, 0.4, 0.25, 1], delay: 0.15 }}
            >
              Why Local Businesses Choose{" "}
              <span className="text-[#e76f51]">Street Savvy</span>{" "}
              Over Traditional Agencies
            </motion.h2>
          </div>
        </motion.div>

        {/* Comparison table */}
        <motion.div
          ref={ref}
          className="rounded-2xl overflow-hidden border border-[#264653]/10"
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, ease: [0.25, 0.4, 0.25, 1] }}
        >
          {/* Header */}
          <div className="grid grid-cols-2 bg-[#264653]">
            <div className="px-6 py-4 text-center">
              <span className="text-sm font-bold text-[#F5F2ED]/60 uppercase tracking-wider">Traditional Agency</span>
            </div>
            <div className="px-6 py-4 text-center border-l border-[#F5F2ED]/10">
              <span className="text-sm font-bold text-[#e76f51] uppercase tracking-wider">Street Savvy Solutions</span>
            </div>
          </div>

          {/* Rows */}
          {comparisons.map((row, i) => (
            <motion.div
              key={i}
              className={`grid grid-cols-2 ${i % 2 === 0 ? "bg-[#264653]/5" : "bg-[#264653]/10"}`}
              initial={{ opacity: 0, x: -20 }}
              animate={isInView ? { opacity: 1, x: 0 } : {}}
              transition={{ delay: 0.2 + i * 0.08, duration: 0.5 }}
            >
              <div className="px-6 py-4 flex items-center gap-3">
                <X className="w-4 h-4 text-[#e76f51]/60 flex-shrink-0" />
                <span className="text-sm text-[#264653]/70">{row.agency}</span>
              </div>
              <div className="px-6 py-4 flex items-center gap-3 border-l border-[#264653]/10">
                <Check className="w-4 h-4 text-[#2a9d8f] flex-shrink-0" />
                <span className="text-sm text-[#1a323d] font-medium">{row.sss}</span>
              </div>
            </motion.div>
          ))}
        </motion.div>

        {/* Below-table copy */}
        <motion.div
          className="mt-10 max-w-3xl mx-auto text-center"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.5 }}
        >
          <p className="text-base md:text-lg text-[#264653]/70 leading-relaxed">
            {"We're not a big agency. We don't have an office full of account managers. What we have is modern technology, deep knowledge of local marketing, and a simple belief:"}{" "}
            <span className="text-[#e76f51] font-semibold">
              your marketing should bring in more money than it costs.
            </span>{" "}
            {"If it doesn't, we haven't done our job."}
          </p>
        </motion.div>
      </div>
    </section>
  )
}
