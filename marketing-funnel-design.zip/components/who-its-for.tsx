"use client"

import { motion, useInView } from "framer-motion"
import { useRef } from "react"
import { Check } from "lucide-react"

const qualifiers = [
  "You're a service business in Metro Atlanta doing great work but struggling to get consistent leads",
  "You've been burned by a marketing agency that charged a lot and delivered reports instead of results",
  "You're the owner, the office manager, AND the marketing department",
  "You know your business should be showing up on Google but you don't have time to figure out why it isn't",
  "You'd rather invest in a system that works than keep throwing money at tactics that don't",
]

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.08,
      delayChildren: 0.2,
    },
  },
}

const itemVariants = {
  hidden: { opacity: 0, x: -20 },
  visible: {
    opacity: 1,
    x: 0,
    transition: {
      type: "spring",
      stiffness: 100,
      damping: 20,
    },
  },
}

export function WhoItsFor() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: "-80px" })

  return (
    <section className="relative py-20 md:py-28 bg-[#264653] overflow-hidden noise-overlay">
      <div className="max-w-4xl mx-auto px-6 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, ease: [0.25, 0.4, 0.25, 1] }}
          className="text-center mb-14"
        >
          <motion.span
            className="font-mono text-[#e9c46a] text-xs tracking-[0.3em] uppercase inline-block"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
          >
            IS THIS FOR YOU?
          </motion.span>

          <div className="overflow-hidden mt-3">
            <motion.h2
              className="text-3xl md:text-5xl font-serif text-[#F5F2ED] leading-tight text-balance"
              initial={{ y: 60 }}
              whileInView={{ y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, ease: [0.25, 0.4, 0.25, 1], delay: 0.15 }}
            >
              Built for Business Owners Who Are{" "}
              <span className="text-[#e76f51]">Done With Marketing That Doesn{"'"}t Work</span>
            </motion.h2>
          </div>

          <motion.p
            className="text-lg text-[#F5F2ED]/60 mt-5"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.4 }}
          >
            This is for you if:
          </motion.p>
        </motion.div>

        <motion.div
          ref={ref}
          className="space-y-4"
          variants={containerVariants}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
        >
          {qualifiers.map((item, i) => (
            <motion.div
              key={i}
              variants={itemVariants}
              whileHover={{
                x: 8,
                transition: { type: "spring", stiffness: 400, damping: 17 },
              }}
              className="flex items-start gap-4 bg-[#1a323d] rounded-xl p-5 border border-[#F5F2ED]/8 cursor-default"
            >
              <div className="w-7 h-7 rounded-full bg-[#e76f51]/15 flex items-center justify-center flex-shrink-0 mt-0.5">
                <Check className="w-4 h-4 text-[#e76f51]" />
              </div>
              <p className="text-[#F5F2ED]/80 text-sm md:text-base leading-relaxed">
                {item}
              </p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}
