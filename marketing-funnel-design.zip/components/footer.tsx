"use client"

import { motion, useInView } from "framer-motion"
import { useRef, useState } from "react"
import Link from "next/link"
import { ArrowRight } from "lucide-react"

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.08,
      delayChildren: 0.15,
    },
  },
}

const itemVariants = {
  hidden: { opacity: 0, y: 15 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      type: "spring",
      stiffness: 100,
      damping: 20,
    },
  },
}

export function Footer() {
  const [isHovering, setIsHovering] = useState(false)
  const footerRef = useRef(null)
  const isInView = useInView(footerRef, { once: true, margin: "-100px" })

  return (
    <footer ref={footerRef} className="relative bg-[#1a323d] pt-0 pb-6 overflow-hidden">
      {/* Final CTA Section */}
      <section id="final-cta" className="relative py-20 md:py-28 bg-[#264653] overflow-hidden noise-overlay border-b border-[#F5F2ED]/8">
        {/* Big ambient glow */}
        <motion.div
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] rounded-full bg-[#e76f51]/8 blur-[250px]"
          animate={{ scale: [1, 1.1, 1] }}
          transition={{ duration: 8, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut" }}
        />

        <div className="max-w-3xl mx-auto px-6 relative z-10 text-center">
          <motion.div
            initial={{ opacity: 0, y: 60 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, ease: [0.25, 0.4, 0.25, 1] }}
          >
            <motion.span
              className="font-mono text-[#e9c46a] text-xs tracking-[0.3em] uppercase inline-block mb-4"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
            >
              TAKE THE NEXT STEP
            </motion.span>

            <h2 className="text-3xl md:text-5xl lg:text-6xl font-serif text-[#F5F2ED] leading-tight overflow-hidden text-balance">
              <motion.span
                className="block"
                initial={{ y: 100 }}
                whileInView={{ y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, ease: [0.25, 0.4, 0.25, 1] }}
              >
                {"Let's Find Out Where"}
              </motion.span>
              <motion.span
                className="block text-[#e76f51]"
                initial={{ y: 100 }}
                whileInView={{ y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, ease: [0.25, 0.4, 0.25, 1], delay: 0.1 }}
              >
                {"You're Losing Leads."}
              </motion.span>
            </h2>
          </motion.div>

          <motion.p
            className="text-[#F5F2ED]/60 text-base md:text-lg mt-6 mb-8 max-w-xl mx-auto leading-relaxed"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.3 }}
          >
            {"Book a free 15-minute Growth Audit. We'll pull up your Google presence, check your response systems, and show you the exact gaps costing you customers."}
          </motion.p>

          <motion.p
            className="text-[#F5F2ED]/40 text-sm mb-8"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.4 }}
          >
            No contracts. No pressure. Just a clear picture of what{"'"}s working and what{"'"}s not.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="flex flex-col items-center gap-4"
          >
            <motion.button
              className="bg-[#e76f51] text-[#F5F2ED] px-10 py-4 rounded-full font-bold text-base tracking-wide flex items-center gap-3 relative overflow-hidden group"
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.98 }}
              transition={{ type: "spring", stiffness: 400, damping: 17 }}
            >
              <motion.div
                className="absolute inset-0 bg-gradient-to-r from-transparent via-[#F5F2ED]/20 to-transparent -translate-x-full"
                whileHover={{ x: "200%" }}
                transition={{ duration: 0.6 }}
              />
              <span className="relative z-10">Get My Free Growth Audit</span>
              <ArrowRight className="w-5 h-5 relative z-10 group-hover:translate-x-1 transition-transform" />
            </motion.button>
            <motion.p
              className="text-[#F5F2ED]/30 font-mono text-xs"
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              transition={{ delay: 0.6 }}
            >
              Takes 2 minutes to book. You{"'"}ll get a custom report whether you hire us or not.
            </motion.p>
          </motion.div>
        </div>
      </section>

      {/* Actual Footer */}
      <div className="max-w-7xl mx-auto px-6 pt-12">
        <motion.div
          className="text-center mb-8"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.3 }}
        >
          <p className="text-[#F5F2ED]/50 text-sm max-w-xl mx-auto leading-relaxed">
            Street Savvy Solutions builds marketing and automation systems for local service businesses in Metro Atlanta. Wall Street results. Main Street prices.
          </p>
        </motion.div>

        <motion.div
          className="grid grid-cols-2 md:grid-cols-4 gap-6 py-8 border-t border-[#F5F2ED]/8"
          variants={containerVariants}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
        >
          {[
            {
              title: "Services",
              links: ["Local SEO", "AI Receptionist", "Websites & Funnels", "Review Generation", "Marketing Automation"],
            },
            {
              title: "Company",
              links: ["About", "How It Works", "Why Us", "Contact"],
            },
            {
              title: "Resources",
              links: ["Free Growth Audit", "Case Studies", "Blog"],
            },
            {
              title: "Legal",
              links: ["Privacy Policy", "Terms of Service"],
            },
          ].map((section) => (
            <motion.div key={section.title} variants={itemVariants}>
              <h4 className="font-bold text-[#F5F2ED] text-sm mb-3">{section.title}</h4>
              <ul className="space-y-2">
                {section.links.map((item) => (
                  <li key={item}>
                    <motion.div whileHover={{ x: 4 }} transition={{ type: "spring", stiffness: 400, damping: 17 }}>
                      <Link
                        href="#"
                        className="text-[#F5F2ED]/50 hover:text-[#f4a261] font-mono text-xs transition-colors inline-block"
                      >
                        {item}
                      </Link>
                    </motion.div>
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </motion.div>

        <motion.div
          className="flex flex-col md:flex-row justify-between items-center pt-6 border-t border-[#F5F2ED]/8 gap-3"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.5 }}
        >
          <motion.div
            className="flex items-center gap-2"
            whileHover={{ scale: 1.05 }}
            transition={{ type: "spring", stiffness: 400, damping: 17 }}
          >
            <span className="text-xl font-serif">
              <span className="text-[#F5F2ED]">Street</span>
              <span className="text-[#e76f51]"> Savvy</span>
            </span>
          </motion.div>

          <p className="text-[#F5F2ED]/30 font-mono text-xs">
            © 2026 Street Savvy Solutions. All rights reserved.
          </p>

          <motion.p
            className="text-[#F5F2ED]/20 font-mono text-xs cursor-pointer"
            onHoverStart={() => setIsHovering(true)}
            onHoverEnd={() => setIsHovering(false)}
            animate={
              isHovering
                ? {
                    rotate: [0, -5, 5, -5, 5, 0],
                    scale: [1, 1.1, 1],
                    color: "#e76f51",
                  }
                : {
                    rotate: 0,
                    scale: 1,
                    color: "rgba(245,242,237,0.2)",
                  }
            }
            transition={{ duration: 0.5 }}
          >
            built with hustle
          </motion.p>
        </motion.div>
      </div>

      {/* Large background text */}
      <motion.div
        className="absolute bottom-0 left-1/2 -translate-x-1/2 text-[10rem] md:text-[20rem] font-serif text-[#F5F2ED]/[0.015] pointer-events-none select-none leading-none whitespace-nowrap"
        initial={{ y: 100, opacity: 0 }}
        whileInView={{ y: 0, opacity: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 1, ease: "easeOut" }}
      >
        STREET SAVVY
      </motion.div>
    </footer>
  )
}
