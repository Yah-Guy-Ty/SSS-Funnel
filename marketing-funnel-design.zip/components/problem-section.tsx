"use client"

import { motion, useInView } from "framer-motion"
import { useRef } from "react"
import { PhoneOff, Globe, Star, DollarSign } from "lucide-react"

const painPoints = [
  {
    icon: PhoneOff,
    title: "Calls go unanswered",
    description: "Leads come in while you're on a job — and nobody picks up. That customer calls the next name on Google.",
  },
  {
    icon: Globe,
    title: "Invisible on Google",
    description: "Your Google listing is half-filled-out, showing the wrong hours. The competitor with worse reviews shows up first.",
  },
  {
    icon: DollarSign,
    title: "Wasted agency spend",
    description: "The marketing agency you hired charged $2,000/month for a pretty website that generated exactly zero calls.",
  },
  {
    icon: Star,
    title: "No reviews coming in",
    description: "Happy customers rarely leave reviews on their own. Your 4 Google reviews aren't competing with the shop that has 200.",
  },
]

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
      delayChildren: 0.2,
    },
  },
}

const itemVariants = {
  hidden: { opacity: 0, y: 30, scale: 0.95 },
  visible: {
    opacity: 1,
    y: 0,
    scale: 1,
    transition: {
      type: "spring",
      stiffness: 100,
      damping: 20,
    },
  },
}

export function ProblemSection() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: "-80px" })

  return (
    <section className="relative py-20 md:py-28 bg-[#F5F2ED] overflow-hidden">
      <div className="max-w-5xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, ease: [0.25, 0.4, 0.25, 1] }}
          className="text-center mb-14"
        >
          <motion.span
            className="font-mono text-[#e76f51] text-xs tracking-[0.3em] uppercase inline-block"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
          >
            THE REAL PROBLEM
          </motion.span>

          <div className="overflow-hidden mt-3">
            <motion.h2
              className="text-3xl md:text-5xl font-serif text-[#1a323d] leading-tight text-balance"
              initial={{ y: 60 }}
              whileInView={{ y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, ease: [0.25, 0.4, 0.25, 1], delay: 0.15 }}
            >
              You Built a Great Business.{" "}
              <span className="text-[#e76f51]">But Nobody Can Find You Online.</span>
            </motion.h2>
          </div>

          <motion.p
            className="text-base md:text-lg text-[#264653]/60 mt-5 max-w-2xl mx-auto leading-relaxed"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.4 }}
          >
            {"Here's what we see over and over with local businesses in Atlanta:"}
          </motion.p>
        </motion.div>

        <motion.div
          ref={ref}
          className="grid md:grid-cols-2 gap-5"
          variants={containerVariants}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
        >
          {painPoints.map((point) => (
            <motion.div
              key={point.title}
              variants={itemVariants}
              whileHover={{
                y: -6,
                transition: { type: "spring", stiffness: 400, damping: 17 },
              }}
              className="group bg-[#264653] rounded-2xl p-6 cursor-default relative overflow-hidden"
            >
              <div className="relative z-10">
                <motion.div
                  className="w-11 h-11 rounded-xl bg-[#e76f51]/15 flex items-center justify-center mb-4"
                  whileHover={{ rotate: 5, scale: 1.05 }}
                  transition={{ type: "spring", stiffness: 400, damping: 17 }}
                >
                  <point.icon className="w-5 h-5 text-[#e76f51]" />
                </motion.div>

                <h3 className="text-lg font-bold text-[#F5F2ED] tracking-tight mb-2">
                  {point.title}
                </h3>
                <p className="text-[#F5F2ED]/60 text-sm leading-relaxed">
                  {point.description}
                </p>
              </div>
            </motion.div>
          ))}
        </motion.div>

        <motion.p
          className="text-center text-lg md:text-xl font-serif text-[#e76f51] mt-12"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.3 }}
        >
          Sound familiar?
        </motion.p>
      </div>
    </section>
  )
}
