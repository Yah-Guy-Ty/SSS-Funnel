"use client"

import { motion } from "framer-motion"
import { Shield, MapPin, Star } from "lucide-react"

const trustItems = [
  { icon: Shield, label: "Google Business Profile Certified Strategies" },
  { icon: Star, label: "5-Step Proven System" },
  { icon: MapPin, label: "Serving Metro Atlanta" },
]

export function TrustBar() {
  return (
    <section className="relative py-6 bg-[#1a323d] border-y border-[#F5F2ED]/8">
      <div className="max-w-5xl mx-auto px-6">
        <motion.div
          className="flex flex-wrap items-center justify-center gap-6 md:gap-10"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          {trustItems.map((item, i) => (
            <motion.div
              key={item.label}
              className="flex items-center gap-2.5 text-[#F5F2ED]/60"
              initial={{ opacity: 0, x: -10 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.15, duration: 0.5 }}
            >
              <item.icon className="w-4 h-4 text-[#f4a261]" />
              <span className="text-xs font-mono tracking-wide">{item.label}</span>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}
