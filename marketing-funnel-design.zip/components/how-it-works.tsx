"use client"

import type React from "react"
import { motion, useInView, useMotionValue, useSpring, useTransform } from "framer-motion"
import { useRef, useState } from "react"
import { Search, MousePointerClick, Zap, CalendarCheck, BarChart3 } from "lucide-react"

const steps = [
  {
    number: "01",
    icon: Search,
    title: "Get Found",
    description:
      "We optimize your Google presence so you show up when locals search for what you do. Not page 2. Not buried under directories. Actually visible in the Map Pack where 93% of clicks happen.",
    accent: "#e76f51",
  },
  {
    number: "02",
    icon: MousePointerClick,
    title: "Capture Attention",
    description:
      "Your website stops being a brochure and starts being a conversion machine — with clear calls to action, mobile-friendly design, and landing pages built to turn visitors into leads.",
    accent: "#f4a261",
  },
  {
    number: "03",
    icon: Zap,
    title: "Respond Instantly",
    description:
      "An AI receptionist answers calls you miss. Text-back automations engage leads within 60 seconds. No more lost opportunities because you were on a job site at 2pm.",
    accent: "#e9c46a",
  },
  {
    number: "04",
    icon: CalendarCheck,
    title: "Book the Job",
    description:
      "Automated follow-up sequences nurture leads until they're ready. Online booking links make it effortless. Your calendar fills without you playing phone tag.",
    accent: "#f4a261",
  },
  {
    number: "05",
    icon: BarChart3,
    title: "See What's Working",
    description:
      "One dashboard shows you exactly how many leads came in, where they came from, and what converted. No vanity metrics. No mystery. Real numbers tied to real revenue.",
    accent: "#e76f51",
  },
]

function StepCard({ step, index }: { step: (typeof steps)[0]; index: number }) {
  const ref = useRef<HTMLDivElement>(null)
  const [isHovered, setIsHovered] = useState(false)

  const x = useMotionValue(0)
  const y = useMotionValue(0)

  const mouseXSpring = useSpring(x, { stiffness: 300, damping: 30 })
  const mouseYSpring = useSpring(y, { stiffness: 300, damping: 30 })

  const rotateX = useTransform(mouseYSpring, [-0.5, 0.5], ["6deg", "-6deg"])
  const rotateY = useTransform(mouseXSpring, [-0.5, 0.5], ["-6deg", "6deg"])

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!ref.current) return
    const rect = ref.current.getBoundingClientRect()
    x.set((e.clientX - rect.left) / rect.width - 0.5)
    y.set((e.clientY - rect.top) / rect.height - 0.5)
  }

  const handleMouseLeave = () => {
    x.set(0)
    y.set(0)
    setIsHovered(false)
  }

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: index * 0.1, ease: [0.25, 0.4, 0.25, 1] }}
      onMouseMove={handleMouseMove}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={handleMouseLeave}
      style={{ rotateX, rotateY, transformStyle: "preserve-3d" }}
      className="relative group"
    >
      {/* Glow on hover */}
      <motion.div
        className="absolute -inset-[1px] rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500"
        style={{
          background: `linear-gradient(135deg, ${step.accent}30, transparent, ${step.accent}30)`,
          filter: "blur(8px)",
        }}
      />

      <div className="relative bg-[#1a323d] rounded-2xl p-6 border border-[#F5F2ED]/8 overflow-hidden h-full">
        {/* Shine effect */}
        <motion.div
          className="absolute inset-0 opacity-0 group-hover:opacity-100"
          initial={false}
          animate={
            isHovered
              ? {
                  background: [
                    "linear-gradient(105deg, transparent 20%, rgba(245,242,237,0.02) 25%, transparent 30%)",
                    "linear-gradient(105deg, transparent 70%, rgba(245,242,237,0.02) 75%, transparent 80%)",
                  ],
                }
              : {}
          }
          transition={{ duration: 1.5, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
        />

        <div className="relative z-10">
          <div className="flex items-center gap-4 mb-4">
            <span className="text-3xl font-serif" style={{ color: step.accent }}>
              {step.number}
            </span>
            <motion.div
              className="w-10 h-10 rounded-xl flex items-center justify-center"
              style={{ backgroundColor: `${step.accent}20` }}
              whileHover={{ scale: 1.1 }}
              transition={{ type: "spring", stiffness: 400, damping: 17 }}
            >
              <step.icon className="w-5 h-5" style={{ color: step.accent }} />
            </motion.div>
          </div>

          <h3 className="text-xl font-bold text-[#F5F2ED] tracking-tight mb-3">
            {step.title}
          </h3>
          <p className="text-[#F5F2ED]/55 text-sm leading-relaxed">
            {step.description}
          </p>

          <motion.div
            className="h-[2px] rounded-full mt-5"
            style={{ backgroundColor: step.accent }}
            initial={{ scaleX: 0, originX: 0 }}
            whileInView={{ scaleX: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.4 + index * 0.1, ease: [0.25, 0.4, 0.25, 1] }}
          />
        </div>
      </div>
    </motion.div>
  )
}

export function HowItWorks() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: "-50px" })

  return (
    <section id="how-it-works" className="relative py-20 md:py-28 bg-[#264653] overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-[#264653] via-[#1e3a47] to-[#264653]" />

      <div ref={ref} className="max-w-6xl mx-auto px-6 relative z-10">
        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : { opacity: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-14"
        >
          <motion.span
            className="inline-block font-mono text-[#f4a261] text-xs tracking-[0.3em] uppercase"
            initial={{ opacity: 0, y: 10 }}
            animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 10 }}
            transition={{ delay: 0.1 }}
          >
            OUR PROCESS
          </motion.span>

          <div className="overflow-hidden mt-3">
            <motion.h2
              className="text-3xl md:text-5xl font-serif text-[#F5F2ED] leading-tight text-balance"
              initial={{ y: 60 }}
              animate={isInView ? { y: 0 } : { y: 60 }}
              transition={{ duration: 0.6, ease: [0.25, 0.4, 0.25, 1], delay: 0.15 }}
            >
              From Invisible to Fully Booked:{" "}
              <span className="text-[#e76f51]">The 5-Step System</span>
            </motion.h2>
          </div>

          <motion.div
            className="h-[2px] w-12 bg-[#e76f51] mx-auto mt-4 rounded-full"
            initial={{ scaleX: 0 }}
            animate={isInView ? { scaleX: 1 } : { scaleX: 0 }}
            transition={{ duration: 0.6, delay: 0.4, ease: [0.25, 0.4, 0.25, 1] }}
          />
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
          {steps.slice(0, 3).map((step, index) => (
            <StepCard key={step.number} step={step} index={index} />
          ))}
        </div>
        <div className="grid md:grid-cols-2 gap-5 mt-5 max-w-4xl mx-auto">
          {steps.slice(3).map((step, index) => (
            <StepCard key={step.number} step={step} index={index + 3} />
          ))}
        </div>
      </div>
    </section>
  )
}
