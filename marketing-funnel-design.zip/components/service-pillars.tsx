"use client"

import { motion, useInView } from "framer-motion"
import { useRef } from "react"
import { MapPin, PhoneIncoming, Settings } from "lucide-react"

const pillars = [
  {
    icon: MapPin,
    title: "Get Found Locally",
    description:
      "If customers can't find you on Google, you don't exist to them. We fix your local SEO, Google Business Profile, and directory listings so you show up where it matters — and show up first.",
    replaces: "What this replaces: hoping referrals keep coming.",
    accent: "#e76f51",
  },
  {
    icon: PhoneIncoming,
    title: "Never Miss a Lead",
    description:
      "Every missed call costs you $200-500 in lifetime value. Our AI receptionist and instant follow-up systems make sure every lead gets a response — even at midnight on a Saturday.",
    replaces: "What this replaces: checking voicemails three days later.",
    accent: "#f4a261",
  },
  {
    icon: Settings,
    title: "Automate the Busywork",
    description:
      "Review requests, appointment reminders, follow-ups, and nurture sequences — all running in the background. You focus on the work that makes you money.",
    replaces: "What this replaces: a sticky note that says \"call back John.\"",
    accent: "#e9c46a",
  },
]

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.12,
      delayChildren: 0.2,
    },
  },
}

const itemVariants = {
  hidden: { opacity: 0, y: 30, scale: 0.95 },
  visible: {
    opacity: 1,
    y: 0,
    scale: 1,
    transition: {
      type: "spring",
      stiffness: 100,
      damping: 20,
    },
  },
}

export function ServicePillars() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: "-80px" })

  return (
    <section id="services" className="relative py-20 md:py-28 bg-[#F5F2ED] overflow-hidden">
      <div className="max-w-6xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, ease: [0.25, 0.4, 0.25, 1] }}
          className="text-center mb-14"
        >
          <motion.span
            className="font-mono text-[#e76f51] text-xs tracking-[0.3em] uppercase inline-block"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
          >
            WHAT WE DO
          </motion.span>

          <div className="overflow-hidden mt-3">
            <motion.h2
              className="text-3xl md:text-5xl font-serif text-[#1a323d] leading-tight text-balance"
              initial={{ y: 60 }}
              whileInView={{ y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, ease: [0.25, 0.4, 0.25, 1], delay: 0.15 }}
            >
              Three Problems. Three Systems.{" "}
              <span className="text-[#e76f51]">One Partner.</span>
            </motion.h2>
          </div>
        </motion.div>

        <motion.div
          ref={ref}
          className="grid md:grid-cols-3 gap-6"
          variants={containerVariants}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
        >
          {pillars.map((pillar) => (
            <motion.div
              key={pillar.title}
              variants={itemVariants}
              whileHover={{
                y: -8,
                scale: 1.02,
                transition: { type: "spring", stiffness: 400, damping: 17 },
              }}
              className="group bg-[#264653] rounded-2xl p-7 cursor-default relative overflow-hidden"
            >
              {/* Hover bg */}
              <motion.div
                className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                style={{
                  background: `linear-gradient(135deg, ${pillar.accent}10, transparent)`,
                }}
              />

              <div className="relative z-10">
                <motion.div
                  className="w-12 h-12 rounded-xl flex items-center justify-center mb-5"
                  style={{ backgroundColor: `${pillar.accent}20` }}
                  whileHover={{ rotate: 10, scale: 1.1 }}
                  transition={{ type: "spring", stiffness: 400, damping: 17 }}
                >
                  <pillar.icon className="w-6 h-6" style={{ color: pillar.accent }} />
                </motion.div>

                <h3 className="text-xl font-bold text-[#F5F2ED] tracking-tight mb-3">
                  {pillar.title}
                </h3>
                <p className="text-[#F5F2ED]/60 text-sm leading-relaxed mb-5">
                  {pillar.description}
                </p>

                <div
                  className="text-xs font-mono italic pt-4 border-t"
                  style={{ color: pillar.accent, borderColor: `${pillar.accent}30` }}
                >
                  {pillar.replaces}
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}
