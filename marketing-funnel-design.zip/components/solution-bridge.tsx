"use client"

import { motion, useInView } from "framer-motion"
import { useRef } from "react"
import { MessageSquare, Clock, Star, BarChart3 } from "lucide-react"

const solutions = [
  {
    icon: MessageSquare,
    text: "Every missed call gets a text-back.",
  },
  {
    icon: Clock,
    text: "Every lead gets an instant response.",
  },
  {
    icon: Star,
    text: "Every happy customer gets asked for a review.",
  },
  {
    icon: BarChart3,
    text: "You see exactly where every lead came from.",
  },
]

export function SolutionBridge() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: "-80px" })

  return (
    <section className="relative py-20 md:py-28 bg-[#264653] overflow-hidden noise-overlay">
      {/* Ambient accent */}
      <motion.div
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full bg-[#e76f51]/5 blur-[200px]"
        animate={{ scale: [1, 1.1, 1] }}
        transition={{ duration: 8, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut" }}
      />

      <div ref={ref} className="max-w-4xl mx-auto px-6 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, ease: [0.25, 0.4, 0.25, 1] }}
          className="text-center mb-14"
        >
          <motion.span
            className="font-mono text-[#f4a261] text-xs tracking-[0.3em] uppercase inline-block"
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
          >
            THE SOLUTION
          </motion.span>

          <div className="overflow-hidden mt-3">
            <motion.h2
              className="text-3xl md:text-5xl font-serif text-[#F5F2ED] leading-tight text-balance"
              initial={{ y: 60 }}
              whileInView={{ y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, ease: [0.25, 0.4, 0.25, 1], delay: 0.15 }}
            >
              What If Your Marketing{" "}
              <span className="text-[#e9c46a]">Ran Itself?</span>
            </motion.h2>
          </div>

          <motion.p
            className="text-base md:text-lg text-[#F5F2ED]/60 mt-5 max-w-2xl mx-auto leading-relaxed"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.4 }}
          >
            {"We don't do \"post and pray\" marketing. We build automated systems that handle the entire journey — from the moment someone Googles your service to the moment they're booked on your calendar."}
          </motion.p>
        </motion.div>

        {/* Solution list */}
        <div className="grid md:grid-cols-2 gap-4 mb-12">
          {solutions.map((item, i) => (
            <motion.div
              key={item.text}
              className="flex items-center gap-4 bg-[#1a323d] rounded-xl p-5 border border-[#F5F2ED]/8"
              initial={{ opacity: 0, x: i % 2 === 0 ? -30 : 30 }}
              animate={isInView ? { opacity: 1, x: 0 } : {}}
              transition={{ delay: 0.2 + i * 0.1, duration: 0.6, ease: [0.25, 0.4, 0.25, 1] }}
            >
              <div className="w-10 h-10 rounded-lg bg-[#e76f51]/15 flex items-center justify-center flex-shrink-0">
                <item.icon className="w-5 h-5 text-[#e76f51]" />
              </div>
              <p className="text-[#F5F2ED]/90 text-sm md:text-base font-medium">{item.text}</p>
            </motion.div>
          ))}
        </div>

        <motion.p
          className="text-center text-xl md:text-2xl font-serif text-[#f4a261]"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.5 }}
        >
          You run your business. The system runs your marketing.
        </motion.p>
      </div>
    </section>
  )
}
