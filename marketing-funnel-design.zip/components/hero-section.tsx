"use client"

import { motion, useScroll, useTransform, useSpring } from "framer-motion"
import { useRef } from "react"
import { ArrowRight } from "lucide-react"

const springConfig = { stiffness: 100, damping: 30, restDelta: 0.001 }

const fadeUpVariants = {
  hidden: { opacity: 0, y: 40 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: {
      delay: i * 0.1,
      duration: 0.8,
      ease: [0.25, 0.4, 0.25, 1],
    },
  }),
}

export function HeroSection() {
  const ref = useRef(null)
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start start", "end start"],
  })

  const rawScale = useTransform(scrollYProgress, [0, 0.5], [1, 0.95])
  const scale = useSpring(rawScale, springConfig)

  const rawOpacity = useTransform(scrollYProgress, [0, 0.8], [1, 0])
  const opacity = useSpring(rawOpacity, springConfig)

  const scrollToAudit = () => {
    const el = document.querySelector("#final-cta")
    if (el) el.scrollIntoView({ behavior: "smooth" })
  }

  return (
    <section
      id="hero"
      ref={ref}
      className="relative min-h-[100vh] flex items-center justify-center overflow-hidden bg-[#264653] noise-overlay"
    >
      {/* Ambient glow orbs */}
      <motion.div
        className="absolute top-20 left-10 w-72 h-72 rounded-full bg-[#e76f51]/10 blur-[120px]"
        animate={{
          x: [0, 30, 0],
          y: [0, -20, 0],
          scale: [1, 1.1, 1],
        }}
        transition={{ duration: 8, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut" }}
      />
      <motion.div
        className="absolute bottom-20 right-10 w-96 h-96 rounded-full bg-[#f4a261]/8 blur-[150px]"
        animate={{
          x: [0, -40, 0],
          y: [0, 30, 0],
          scale: [1, 1.2, 1],
        }}
        transition={{ duration: 10, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut" }}
      />

      <motion.div style={{ opacity, scale }} className="relative z-10 max-w-4xl mx-auto px-6 pt-32 pb-20 text-center">
        {/* Badge */}
        <motion.div
          variants={fadeUpVariants}
          initial="hidden"
          animate="visible"
          custom={0}
          className="inline-flex items-center gap-2 bg-[#1a323d] text-[#f4a261] px-4 py-2 rounded-full text-xs font-mono tracking-wider mb-8 border border-[#f4a261]/20"
        >
          <motion.span
            className="w-2 h-2 bg-[#e76f51] rounded-full"
            animate={{ scale: [1, 1.2, 1], opacity: [1, 0.7, 1] }}
            transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut" }}
          />
          SERVING METRO ATLANTA LOCAL BUSINESSES
        </motion.div>

        {/* Headline */}
        <div className="space-y-2 overflow-hidden mb-8">
          <motion.h1
            variants={fadeUpVariants}
            initial="hidden"
            animate="visible"
            custom={1}
            className="text-4xl md:text-6xl lg:text-7xl font-serif text-[#F5F2ED] leading-[1.05] text-balance"
          >
            Your Business Runs on
          </motion.h1>
          <motion.h1
            variants={fadeUpVariants}
            initial="hidden"
            animate="visible"
            custom={2}
            className="text-4xl md:text-6xl lg:text-7xl font-serif leading-[1.05]"
          >
            <span className="text-[#e76f51]">Referrals and Hope.</span>
          </motion.h1>
          <motion.h2
            variants={fadeUpVariants}
            initial="hidden"
            animate="visible"
            custom={3}
            className="text-2xl md:text-3xl lg:text-4xl font-serif text-[#f4a261] leading-[1.15] pt-2"
          >
            We Build the System That Replaces Both.
          </motion.h2>
        </div>

        {/* Subheadline */}
        <motion.p
          variants={fadeUpVariants}
          initial="hidden"
          animate="visible"
          custom={4}
          className="text-base md:text-lg text-[#F5F2ED]/70 max-w-2xl mx-auto leading-relaxed mb-10"
        >
          We build marketing and automation systems that get Metro Atlanta service businesses found on Google,
          responding to leads in seconds, and booking more jobs — without you touching a thing.
        </motion.p>

        {/* CTA */}
        <motion.div
          variants={fadeUpVariants}
          initial="hidden"
          animate="visible"
          custom={5}
          className="flex flex-col items-center gap-4"
        >
          <motion.button
            onClick={scrollToAudit}
            className="bg-[#e76f51] text-[#F5F2ED] px-8 py-4 rounded-full font-bold text-base tracking-wide flex items-center gap-3 group relative overflow-hidden"
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.98 }}
            transition={{ type: "spring", stiffness: 400, damping: 17 }}
          >
            <motion.div
              className="absolute inset-0 bg-gradient-to-r from-transparent via-[#F5F2ED]/20 to-transparent -translate-x-full"
              whileHover={{ x: "200%" }}
              transition={{ duration: 0.6 }}
            />
            <span className="relative z-10">Get Your Free Growth Audit</span>
            <ArrowRight className="w-5 h-5 relative z-10 group-hover:translate-x-1 transition-transform" />
          </motion.button>
          <motion.p
            variants={fadeUpVariants}
            initial="hidden"
            animate="visible"
            custom={6}
            className="text-[#F5F2ED]/40 text-sm font-mono"
          >
            Takes 2 minutes. No credit card. No sales pitch.
          </motion.p>
        </motion.div>

        {/* Stat highlights */}
        <motion.div
          variants={fadeUpVariants}
          initial="hidden"
          animate="visible"
          custom={7}
          className="flex flex-wrap justify-center gap-6 md:gap-10 pt-14"
        >
          {[
            { stat: "67%", label: "of inbound calls missed" },
            { stat: "60s", label: "AI response time" },
            { stat: "2 weeks", label: "to launch" },
          ].map((item, i) => (
            <motion.div
              key={item.label}
              className="flex flex-col items-center gap-1"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 1 + i * 0.15 }}
            >
              <span className="text-2xl md:text-3xl font-serif text-[#e9c46a]">{item.stat}</span>
              <span className="text-xs text-[#F5F2ED]/50 font-mono">{item.label}</span>
            </motion.div>
          ))}
        </motion.div>
      </motion.div>

      {/* Scroll indicator */}
      <motion.div
        className="absolute bottom-8 left-1/2 -translate-x-1/2"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1.5, duration: 0.8 }}
      >
        <motion.div
          animate={{ y: [0, 8, 0] }}
          transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut" }}
        >
          <div className="w-5 h-8 border-2 border-[#F5F2ED]/20 rounded-full flex justify-center pt-1.5">
            <motion.div
              className="w-1 h-2 bg-[#e76f51] rounded-full"
              animate={{ y: [0, 6, 0], opacity: [1, 0.5, 1] }}
              transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut" }}
            />
          </div>
        </motion.div>
      </motion.div>
    </section>
  )
}
