import { Navigation } from "@/components/navigation"
import { HeroSection } from "@/components/hero-section"
import { TrustBar } from "@/components/trust-bar"
import { ProblemSection } from "@/components/problem-section"
import { SolutionBridge } from "@/components/solution-bridge"
import { HowItWorks } from "@/components/how-it-works"
import { ServicePillars } from "@/components/service-pillars"
import { WhoItsFor } from "@/components/who-its-for"
import { ComparisonSection } from "@/components/comparison-section"
import { FounderStory } from "@/components/founder-story"
import { Footer } from "@/components/footer"

export default function Home() {
  return (
    <main className="min-h-screen bg-[#264653]">
      <Navigation />
      <HeroSection />
      <TrustBar />
      <ProblemSection />
      <SolutionBridge />
      <HowItWorks />
      <ServicePillars />
      <WhoItsFor />
      <ComparisonSection />
      <FounderStory />
      <Footer />
    </main>
  )
}
