import type React from "react"
import type { Metadata, Viewport } from "next"
import { DM_Sans, DM_Serif_Display, JetBrains_Mono } from "next/font/google"
import { Analytics } from "@vercel/analytics/next"
import { LenisProvider } from "@/components/lenis-provider"
import ClickSpark from "@/components/click-spark"
import "./globals.css"

const _dmSans = DM_Sans({
  subsets: ["latin"],
  variable: "--font-sans",
})

const _dmSerifDisplay = DM_Serif_Display({
  weight: "400",
  subsets: ["latin"],
  variable: "--font-serif",
})

const _jetbrainsMono = JetBrains_Mono({
  subsets: ["latin"],
  variable: "--font-mono",
})

export const metadata: Metadata = {
  title: "Street Savvy Solutions | AI Marketing & Automation for Atlanta Local Businesses",
  description:
    "We build lead generation and automation systems for local service businesses in Metro Atlanta. AI receptionists, local SEO, review systems, and more. Free growth audit available.",
  keywords: [
    "local business marketing",
    "Atlanta marketing",
    "AI automation",
    "lead generation",
    "local SEO",
    "Street Savvy Solutions",
  ],
  generator: "v0.app",
}

export const viewport: Viewport = {
  themeColor: "#264653",
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className="font-sans antialiased" suppressHydrationWarning>
        <ClickSpark
          sparkColor="#e76f51"
          sparkSize={12}
          sparkRadius={20}
          sparkCount={8}
          duration={400}
          easing="ease-out"
        >
          <LenisProvider>{children}</LenisProvider>
        </ClickSpark>
        <Analytics />
      </body>
    </html>
  )
}
